# 1527. Patients With a Condition

[Problem on LeetCode](https://leetcode.com/problems/patients-with-a-condition/)

**Status:** To do

## My solution

```sql

```

## Notes

