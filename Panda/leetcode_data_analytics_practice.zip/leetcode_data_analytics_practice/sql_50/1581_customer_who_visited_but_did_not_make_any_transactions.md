# 1581. Customer Who Visited but Did Not Make Any Transactions

[Problem on LeetCode](https://leetcode.com/problems/customer-who-visited-but-did-not-make-any-transactions/)

**Status:** To do

## My solution

```sql

```

## Notes

