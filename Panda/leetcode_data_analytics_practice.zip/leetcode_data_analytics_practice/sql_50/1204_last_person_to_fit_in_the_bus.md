# 1204. Last Person to Fit in the Bus

[Problem on LeetCode](https://leetcode.com/problems/last-person-to-fit-in-the-bus/)

**Status:** To do

## My solution

```sql

```

## Notes

