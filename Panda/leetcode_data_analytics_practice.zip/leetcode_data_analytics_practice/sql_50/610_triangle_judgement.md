# 610. Triangle Judgement

[Problem on LeetCode](https://leetcode.com/problems/triangle-judgement/)

**Status:** To do

## My solution

```sql

```

## Notes

