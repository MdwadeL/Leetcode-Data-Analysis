# 1978. Employees Whose Manager Left the Company

[Problem on LeetCode](https://leetcode.com/problems/employees-whose-manager-left-the-company/)

**Status:** To do

## My solution

```sql

```

## Notes

