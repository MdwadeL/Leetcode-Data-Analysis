# 1661. Average Time of Process per Machine

[Problem on LeetCode](https://leetcode.com/problems/average-time-of-process-per-machine/)

**Status:** To do

## My solution

```sql

```

## Notes

