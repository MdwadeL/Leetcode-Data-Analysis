# 1068. Product Sales Analysis I

[Problem on LeetCode](https://leetcode.com/problems/product-sales-analysis-i/)

**Status:** To do

## My solution

```sql

```

## Notes

