# 1321. Restaurant Growth

[Problem on LeetCode](https://leetcode.com/problems/restaurant-growth/)

**Status:** To do

## My solution

```sql

```

## Notes

