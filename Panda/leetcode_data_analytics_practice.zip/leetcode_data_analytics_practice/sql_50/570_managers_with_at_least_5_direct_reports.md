# 570. Managers with at Least 5 Direct Reports

[Problem on LeetCode](https://leetcode.com/problems/managers-with-at-least-5-direct-reports/)

**Status:** To do

## My solution

```sql

```

## Notes

