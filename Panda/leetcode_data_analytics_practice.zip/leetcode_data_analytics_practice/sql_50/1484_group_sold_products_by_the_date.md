# 1484. Group Sold Products By The Date

[Problem on LeetCode](https://leetcode.com/problems/group-sold-products-by-the-date/)

**Status:** To do

## My solution

```sql

```

## Notes

