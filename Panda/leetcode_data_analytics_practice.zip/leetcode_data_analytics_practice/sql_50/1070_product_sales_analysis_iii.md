# 1070. Product Sales Analysis III

[Problem on LeetCode](https://leetcode.com/problems/product-sales-analysis-iii/)

**Status:** To do

## My solution

```sql

```

## Notes

