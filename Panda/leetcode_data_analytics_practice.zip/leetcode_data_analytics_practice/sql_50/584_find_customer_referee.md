# 584. Find Customer Referee

[Problem on LeetCode](https://leetcode.com/problems/find-customer-referee/)

**Status:** Completed on LeetCode; add your solution here

## My solution

```sql

```

## Notes

