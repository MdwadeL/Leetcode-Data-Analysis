# 1148. Article Views I

[Problem on LeetCode](https://leetcode.com/problems/article-views-i/)

**Status:** Completed on LeetCode; add your solution here

## My solution

```sql

```

## Notes

