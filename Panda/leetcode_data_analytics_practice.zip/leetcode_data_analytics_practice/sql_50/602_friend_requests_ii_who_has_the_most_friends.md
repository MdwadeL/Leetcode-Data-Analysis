# 602. Friend Requests II: Who Has the Most Friends

[Problem on LeetCode](https://leetcode.com/problems/friend-requests-ii-who-has-the-most-friends/)

**Status:** To do

## My solution

```sql

```

## Notes

