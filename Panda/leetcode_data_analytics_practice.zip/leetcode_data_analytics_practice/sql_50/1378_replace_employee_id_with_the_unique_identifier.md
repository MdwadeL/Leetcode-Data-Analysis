# 1378. Replace Employee ID With The Unique Identifier

[Problem on LeetCode](https://leetcode.com/problems/replace-employee-id-with-the-unique-identifier/)

**Status:** To do

## My solution

```sql

```

## Notes

