# 1667. Fix Names in a Table

[Problem on LeetCode](https://leetcode.com/problems/fix-names-in-a-table/)

**Status:** To do

## My solution

```sql

```

## Notes

