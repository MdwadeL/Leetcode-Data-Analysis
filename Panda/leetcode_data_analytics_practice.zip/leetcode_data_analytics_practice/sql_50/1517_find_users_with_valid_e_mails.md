# 1517. Find Users With Valid E-Mails

[Problem on LeetCode](https://leetcode.com/problems/find-users-with-valid-e-mails/)

**Status:** To do

## My solution

```sql

```

## Notes

