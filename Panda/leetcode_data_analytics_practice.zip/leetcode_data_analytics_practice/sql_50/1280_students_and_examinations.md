# 1280. Students and Examinations

[Problem on LeetCode](https://leetcode.com/problems/students-and-examinations/)

**Status:** To do

## My solution

```sql

```

## Notes

