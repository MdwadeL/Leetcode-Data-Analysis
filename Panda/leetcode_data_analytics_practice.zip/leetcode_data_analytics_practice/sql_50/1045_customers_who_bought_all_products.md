# 1045. Customers Who Bought All Products

[Problem on LeetCode](https://leetcode.com/problems/customers-who-bought-all-products/)

**Status:** To do

## My solution

```sql

```

## Notes

