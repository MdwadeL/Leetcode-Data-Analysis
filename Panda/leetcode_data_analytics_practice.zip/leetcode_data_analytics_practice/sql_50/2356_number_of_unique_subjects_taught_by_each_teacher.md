# 2356. Number of Unique Subjects Taught by Each Teacher

[Problem on LeetCode](https://leetcode.com/problems/number-of-unique-subjects-taught-by-each-teacher/)

**Status:** To do

## My solution

```sql

```

## Notes

