# 595. Big Countries

[Problem on LeetCode](https://leetcode.com/problems/big-countries/)

**Status:** Completed on LeetCode; add your solution here

## My solution

```sql

```

## Notes

