# 619. Biggest Single Number

[Problem on LeetCode](https://leetcode.com/problems/biggest-single-number/)

**Status:** To do

## My solution

```sql

```

## Notes

