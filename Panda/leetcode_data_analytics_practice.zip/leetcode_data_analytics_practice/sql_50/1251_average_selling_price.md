# 1251. Average Selling Price

[Problem on LeetCode](https://leetcode.com/problems/average-selling-price/)

**Status:** To do

## My solution

```sql

```

## Notes

