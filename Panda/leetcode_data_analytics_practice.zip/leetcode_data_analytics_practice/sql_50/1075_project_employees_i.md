# 1075. Project Employees I

[Problem on LeetCode](https://leetcode.com/problems/project-employees-i/)

**Status:** To do

## My solution

```sql

```

## Notes

