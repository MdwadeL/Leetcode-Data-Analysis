# 180. Consecutive Numbers

[Problem on LeetCode](https://leetcode.com/problems/consecutive-numbers/)

**Status:** To do

## My solution

```sql

```

## Notes

