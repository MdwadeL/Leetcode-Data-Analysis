# 1341. Movie Rating

[Problem on LeetCode](https://leetcode.com/problems/movie-rating/)

**Status:** To do

## My solution

```sql

```

## Notes

