# 1633. Percentage of Users Attended a Contest

[Problem on LeetCode](https://leetcode.com/problems/percentage-of-users-attended-a-contest/)

**Status:** To do

## My solution

```sql

```

## Notes

