# 185. Department Top Three Salaries

[Problem on LeetCode](https://leetcode.com/problems/department-top-three-salaries/)

**Status:** To do

## My solution

```sql

```

## Notes

