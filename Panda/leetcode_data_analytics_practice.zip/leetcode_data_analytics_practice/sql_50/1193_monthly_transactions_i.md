# 1193. Monthly Transactions I

[Problem on LeetCode](https://leetcode.com/problems/monthly-transactions-i/)

**Status:** To do

## My solution

```sql

```

## Notes

