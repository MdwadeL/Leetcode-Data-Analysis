# 620. Not Boring Movies

[Problem on LeetCode](https://leetcode.com/problems/not-boring-movies/)

**Status:** To do

## My solution

```sql

```

## Notes

