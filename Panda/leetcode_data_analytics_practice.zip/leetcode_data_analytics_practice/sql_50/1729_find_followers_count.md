# 1729. Find Followers Count

[Problem on LeetCode](https://leetcode.com/problems/find-followers-count/)

**Status:** To do

## My solution

```sql

```

## Notes

