# 626. Exchange Seats

[Problem on LeetCode](https://leetcode.com/problems/exchange-seats/)

**Status:** To do

## My solution

```sql

```

## Notes

