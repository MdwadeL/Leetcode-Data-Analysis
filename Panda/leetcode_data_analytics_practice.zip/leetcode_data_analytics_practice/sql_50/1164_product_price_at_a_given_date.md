# 1164. Product Price at a Given Date

[Problem on LeetCode](https://leetcode.com/problems/product-price-at-a-given-date/)

**Status:** To do

## My solution

```sql

```

## Notes

