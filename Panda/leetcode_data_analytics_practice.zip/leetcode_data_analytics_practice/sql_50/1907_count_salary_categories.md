# 1907. Count Salary Categories

[Problem on LeetCode](https://leetcode.com/problems/count-salary-categories/)

**Status:** To do

## My solution

```sql

```

## Notes

