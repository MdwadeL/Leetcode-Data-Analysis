# 196. Delete Duplicate Emails

[Problem on LeetCode](https://leetcode.com/problems/delete-duplicate-emails/)

**Status:** To do

## My solution

```sql

```

## Notes

