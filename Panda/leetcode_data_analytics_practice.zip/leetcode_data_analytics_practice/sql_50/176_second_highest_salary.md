# 176. Second Highest Salary

[Problem on LeetCode](https://leetcode.com/problems/second-highest-salary/)

**Status:** To do

## My solution

```sql

```

## Notes

