# 1211. Queries Quality and Percentage

[Problem on LeetCode](https://leetcode.com/problems/queries-quality-and-percentage/)

**Status:** To do

## My solution

```sql

```

## Notes

