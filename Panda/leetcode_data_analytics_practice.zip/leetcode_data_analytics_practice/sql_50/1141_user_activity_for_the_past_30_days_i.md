# 1141. User Activity for the Past 30 Days I

[Problem on LeetCode](https://leetcode.com/problems/user-activity-for-the-past-30-days-i/)

**Status:** To do

## My solution

```sql

```

## Notes

