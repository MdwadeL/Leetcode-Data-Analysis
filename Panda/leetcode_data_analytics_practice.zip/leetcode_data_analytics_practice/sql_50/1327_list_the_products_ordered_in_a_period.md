# 1327. List the Products Ordered in a Period

[Problem on LeetCode](https://leetcode.com/problems/list-the-products-ordered-in-a-period/)

**Status:** To do

## My solution

```sql

```

## Notes

