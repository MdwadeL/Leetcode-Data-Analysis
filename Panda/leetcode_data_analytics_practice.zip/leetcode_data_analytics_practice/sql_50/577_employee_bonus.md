# 577. Employee Bonus

[Problem on LeetCode](https://leetcode.com/problems/employee-bonus/)

**Status:** To do

## My solution

```sql

```

## Notes

