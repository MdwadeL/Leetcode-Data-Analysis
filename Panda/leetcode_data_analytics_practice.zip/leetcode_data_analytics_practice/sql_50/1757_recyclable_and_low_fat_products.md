# 1757. Recyclable and Low Fat Products

[Problem on LeetCode](https://leetcode.com/problems/recyclable-and-low-fat-products/)

**Status:** Completed on LeetCode; add your solution here

## My solution

```sql

```

## Notes

