# 585. Investments in 2016

[Problem on LeetCode](https://leetcode.com/problems/investments-in-2016/)

**Status:** To do

## My solution

```sql

```

## Notes

