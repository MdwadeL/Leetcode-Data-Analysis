# 596. Classes More Than 5 Students

[Problem on LeetCode](https://leetcode.com/problems/classes-more-than-5-students/)

**Status:** To do

## My solution

```sql

```

## Notes

