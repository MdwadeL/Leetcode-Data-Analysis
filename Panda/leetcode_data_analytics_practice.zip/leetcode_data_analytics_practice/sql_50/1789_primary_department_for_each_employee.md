# 1789. Primary Department for Each Employee

[Problem on LeetCode](https://leetcode.com/problems/primary-department-for-each-employee/)

**Status:** To do

## My solution

```sql

```

## Notes

