# 1683. Invalid Tweets

[Problem on LeetCode](https://leetcode.com/problems/invalid-tweets/)

**Status:** Completed on LeetCode; add your solution here

## My solution

```sql

```

## Notes

