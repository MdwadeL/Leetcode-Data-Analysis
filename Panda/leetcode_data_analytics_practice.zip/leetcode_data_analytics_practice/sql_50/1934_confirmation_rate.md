# 1934. Confirmation Rate

[Problem on LeetCode](https://leetcode.com/problems/confirmation-rate/)

**Status:** To do

## My solution

```sql

```

## Notes

