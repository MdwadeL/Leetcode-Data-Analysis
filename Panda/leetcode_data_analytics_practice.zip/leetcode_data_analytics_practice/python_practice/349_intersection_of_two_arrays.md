# 349. Intersection of Two Arrays

[Problem on LeetCode](https://leetcode.com/problems/intersection-of-two-arrays/)

**Status:** To do

## My solution

```python

```

## Notes

