# 242. Valid Anagram

[Problem on LeetCode](https://leetcode.com/problems/valid-anagram/)

**Status:** To do

## My solution

```python

```

## Notes

