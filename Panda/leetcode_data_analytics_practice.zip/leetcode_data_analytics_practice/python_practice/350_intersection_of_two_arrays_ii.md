# 350. Intersection of Two Arrays II

[Problem on LeetCode](https://leetcode.com/problems/intersection-of-two-arrays-ii/)

**Status:** To do

## My solution

```python

```

## Notes

