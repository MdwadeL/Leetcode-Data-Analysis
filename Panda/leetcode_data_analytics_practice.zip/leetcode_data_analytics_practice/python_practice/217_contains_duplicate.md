# 217. Contains Duplicate

[Problem on LeetCode](https://leetcode.com/problems/contains-duplicate/)

**Status:** To do

## My solution

```python

```

## Notes

