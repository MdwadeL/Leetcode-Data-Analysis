# 387. First Unique Character in a String

[Problem on LeetCode](https://leetcode.com/problems/first-unique-character-in-a-string/)

**Status:** To do

## My solution

```python

```

## Notes

