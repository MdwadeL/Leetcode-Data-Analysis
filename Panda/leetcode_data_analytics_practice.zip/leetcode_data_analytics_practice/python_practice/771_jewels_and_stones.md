# 771. Jewels and Stones

[Problem on LeetCode](https://leetcode.com/problems/jewels-and-stones/)

**Status:** To do

## My solution

```python

```

## Notes

