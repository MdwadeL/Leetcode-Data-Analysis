# 1365. How Many Numbers Are Smaller Than the Current Number

[Problem on LeetCode](https://leetcode.com/problems/how-many-numbers-are-smaller-than-the-current-number/)

**Status:** To do

## My solution

```python

```

## Notes

