# 1. Two Sum

[Problem on LeetCode](https://leetcode.com/problems/two-sum/)

**Status:** To do

## My solution

```python

```

## Notes

