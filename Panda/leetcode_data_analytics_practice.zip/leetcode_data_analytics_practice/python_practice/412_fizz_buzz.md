# 412. Fizz Buzz

[Problem on LeetCode](https://leetcode.com/problems/fizz-buzz/)

**Status:** To do

## My solution

```python

```

## Notes

